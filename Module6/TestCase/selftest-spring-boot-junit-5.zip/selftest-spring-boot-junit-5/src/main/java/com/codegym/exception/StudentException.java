package com.codegym.exception;

public class StudentException extends Exception {
}
