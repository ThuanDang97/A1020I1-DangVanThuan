package com.codegym.model.service;

import com.codegym.model.entity.ClassStudent;

import java.util.List;

public interface IClassStudentService {
    List<ClassStudent> findAll();
}
